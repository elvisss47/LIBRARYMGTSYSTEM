import javax.swing.*;
import java.awt.*;

/**
 * The Swing window. It talks to a single Library object.
 */
public class LibraryGUI extends JFrame {
    private Library library = new Library();

    private JTextField titleField = new JTextField(12);
    private JTextField authorField = new JTextField(12);
    private JTextField nameField = new JTextField(12);
    private JTextField bookIdField = new JTextField(5);
    private JTextField memberIdField = new JTextField(5);
    private JTextField searchField = new JTextField(12);
    private JComboBox<String> sortBox =
            new JComboBox<>(new String[]{"Sort by ID", "Sort by Title", "Sort by Author"});
    private JTextArea output = new JTextArea(14, 60);

    public LibraryGUI() {
        setTitle("Library Management System");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(5, 5));

        // ----- Top: input panels -----
        JPanel top = new JPanel(new GridLayout(4, 1, 5, 5));

        JPanel p1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton addBtn = new JButton("Add Book");
        p1.add(new JLabel("Title:"));  p1.add(titleField);
        p1.add(new JLabel("Author:")); p1.add(authorField);
        p1.add(addBtn);

        JPanel p2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton regBtn = new JButton("Register Member");
        p2.add(new JLabel("Member name:")); p2.add(nameField);
        p2.add(regBtn);

        JPanel p3 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton borrowBtn = new JButton("Borrow");
        JButton returnBtn = new JButton("Return");
        p3.add(new JLabel("Book ID:"));   p3.add(bookIdField);
        p3.add(new JLabel("Member ID:")); p3.add(memberIdField);
        p3.add(borrowBtn); p3.add(returnBtn);

        JPanel p4 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton searchBtn = new JButton("Search Books");
        p4.add(new JLabel("Keyword:")); p4.add(searchField);
        p4.add(searchBtn);

        top.add(p1); top.add(p2); top.add(p3); top.add(p4);

        // ----- Bottom: list buttons -----
        JPanel bottom = new JPanel();
        JButton showBooks = new JButton("Show Books");
        JButton showMembers = new JButton("Show Members");
        bottom.add(sortBox);
        bottom.add(showBooks);
        bottom.add(showMembers);

        // ----- Centre: output -----
        output.setEditable(false);
        output.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(output), BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);

        // ----- Event handlers -----
        addBtn.addActionListener(e -> handleAddBook());
        regBtn.addActionListener(e -> handleRegister());
        borrowBtn.addActionListener(e -> handleBorrowReturn(true));
        returnBtn.addActionListener(e -> handleBorrowReturn(false));
        searchBtn.addActionListener(e -> handleSearch());
        showBooks.addActionListener(e -> handleShowBooks());
        showMembers.addActionListener(e -> output.setText(library.listMembers()));

        pack();
        setLocationRelativeTo(null);
    }

    private void handleAddBook() {
        String t = titleField.getText().trim();
        String a = authorField.getText().trim();
        if (t.isEmpty() || a.isEmpty()) {
            output.setText("Please enter both title and author.");
        } else if (library.addBook(t, a)) {
            output.setText("Book added: " + t);
            titleField.setText("");
            authorField.setText("");
        } else {
            output.setText("The library is full.");
        }
    }

    private void handleRegister() {
        String n = nameField.getText().trim();
        if (n.isEmpty()) {
            output.setText("Please enter the member's name.");
        } else if (library.registerMember(n)) {
            output.setText("Member registered: " + n);
            nameField.setText("");
        } else {
            output.setText("Cannot register more members.");
        }
    }

    private void handleBorrowReturn(boolean borrow) {
        try {
            int bId = Integer.parseInt(bookIdField.getText().trim());
            int mId = Integer.parseInt(memberIdField.getText().trim());
            if (borrow) {
                output.setText(library.borrowBook(bId, mId));
            } else {
                output.setText(library.returnBook(bId, mId));
            }
        } catch (NumberFormatException ex) {
            output.setText("Book ID and Member ID must be whole numbers.");
        }
    }

    private void handleSearch() {
        String k = searchField.getText().trim();
        if (k.isEmpty()) {
            output.setText("Please type a keyword to search.");
        } else {
            output.setText(library.searchBooks(k));
        }
    }

    private void handleShowBooks() {
        int mode;
        switch (sortBox.getSelectedIndex()) {
            case 1:
                mode = Library.SORT_BY_TITLE;
                break;
            case 2:
                mode = Library.SORT_BY_AUTHOR;
                break;
            default:
                mode = Library.SORT_BY_ID;
        }
        output.setText(library.listBooks(mode));
    }
}

# Library Management System

A simple Java Swing application for the CSC 1102 practical exam project.

## Features
- Add books and register members
- Borrow and return books (max 3 per member)
- Search books by title or author
- List books sorted by ID, title or author
- List members and the books they currently hold

## Classes
| Class | Purpose |
|---|---|
| `Book` | A book (id, title, author, availability) |
| `Member` | A reader, with an array of borrowed books |
| `Library` | Holds `Book[]` and `Member[]` and the main logic |
| `LibraryGUI` | The Swing window |
| `Main` | Entry point (group details in the header comment) |

## How to run
Requires JDK 17+.

```
cd src
javac *.java
java Main
```

Or open the `src` folder in IntelliJ / Eclipse / NetBeans and run `Main`.
